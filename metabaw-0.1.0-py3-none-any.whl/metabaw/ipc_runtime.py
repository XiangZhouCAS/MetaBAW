"""Private local Python IPC paths, separate from potentially large workflow scratch."""
from __future__ import annotations

from contextlib import contextmanager
import os
from pathlib import Path
import re
import shutil
import socket
import sys
import tempfile
from typing import Iterator


def socket_path_too_long(configured: Path) -> bool:
    probe = configured / "pymp-12345678" / "listener-12345678"
    return len(os.fsencode(str(probe))) >= 100


def filesystem_type(path: Path) -> str | None:
    """Read Linux mount metadata; use the deepest mount containing this path."""
    try:
        lines = Path("/proc/self/mountinfo").read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    matches = []
    for line in lines:
        fields = line.split()
        try:
            separator = fields.index("-")
            mount = Path(re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4]))
            if path.is_relative_to(mount):
                matches.append((len(mount.parts), fields[separator + 1]))
        except (ValueError, IndexError):
            continue
    return max(matches)[1] if matches else None


@contextmanager
def task_python_runtime(environment: dict[str, str], scratch: Path, *, gpu: bool
                        ) -> Iterator[tuple[Path, Path]]:
    """Install an inherited startup adapter without changing TMPDIR or task inputs."""
    default = "/tmp" if os.name == "posix" else tempfile.gettempdir()
    parent = Path(environment.get("METABAW_LOCAL_TMPDIR") or default).expanduser().resolve()
    # The startup adapter sets the actual multiprocessing directory directly;
    # unlike tempfile-based wrappers, no extra pymp-XXXXXXXX level is added.
    if len(os.fsencode(str(parent / "mbw-ipc-12345678" / "listener-12345678"))) >= 100:
        raise ValueError("METABAW_LOCAL_TMPDIR is too long for Python worker sockets; "
                         "choose a short local path such as /tmp")
    filesystem = filesystem_type(parent)
    if filesystem in {"nfs", "nfs4", "cifs", "smb3", "fuse.sshfs"}:
        raise ValueError(f"Python worker IPC parent {parent} is on {filesystem}; "
                         "set METABAW_LOCAL_TMPDIR to a short local filesystem path")
    parent.mkdir(parents=True, exist_ok=True)
    private = Path(tempfile.mkdtemp(prefix="mbw-ipc-", dir=parent))
    hook = None
    try:
        # Check the actual filesystem/socket support before starting analysis.
        if os.name == "posix" and hasattr(socket, "AF_UNIX"):
            probe = private / "probe"
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as listener:
                listener.bind(str(probe))
            probe.unlink()
        scratch.mkdir(parents=True, exist_ok=True)
        hook = Path(tempfile.mkdtemp(prefix=".metabaw-python-", dir=scratch))
        source = Path(__file__).parent
        shutil.copyfile(source / "python_startup.py", hook / "sitecustomize.py")
        if gpu:
            shutil.copyfile(source / "gpu_limits.py", hook / "metabaw_gpu_limits.py")
            environment["CUPY_GPU_MEMORY_LIMIT"] = environment.get(
                "METABAW_GPU_ALLOCATOR_BYTES", environment["METABAW_GPU_BUDGET_BYTES"])
        environment["METABAW_PYTHON_GPU_HOOK"] = "1" if gpu else "0"
        environment["METABAW_IPC_TMPDIR"] = str(private)
        environment["PYTHONPATH"] = os.pathsep.join(filter(None, (str(hook), environment.get("PYTHONPATH"))))
        yield hook, private
    finally:
        for owned in (hook, private):
            if owned is not None:
                try:
                    shutil.rmtree(owned)
                except FileNotFoundError:
                    pass
                except OSError as exc:
                    print(f"[WARNING] Could not remove private task runtime directory {owned}: {exc}",
                          file=sys.stderr, flush=True)
