"""Inherited stdlib-only sitecustomize; also runs in MetaWRAP's Python 2.7.

Only multiprocessing's communication directory is changed. tempfile/TMPDIR
remain under the configured workflow scratch, including for native children.
"""
from __future__ import print_function

import os
import sys


def install_ipc():
    directory = os.environ.get("METABAW_IPC_TMPDIR")
    if not directory:
        return
    probe = os.path.join(directory, "listener-12345678")
    encoded = os.fsencode(probe) if hasattr(os, "fsencode") else probe
    if len(encoded) >= 100 or not os.path.isdir(directory):
        raise RuntimeError("invalid private Python IPC directory: " + directory)
    from multiprocessing import process
    current = process.current_process()
    if hasattr(current, "_config"):
        current._config["tempdir"] = directory
    elif hasattr(current, "_tempdir"):
        # Python 2.7 uses a dedicated field rather than Python 3's config map.
        current._tempdir = directory
    else:
        raise RuntimeError("unsupported multiprocessing temporary-directory interface")


def install_gpu():
    if os.environ.get("METABAW_PYTHON_GPU_HOOK") == "1":
        import metabaw_gpu_limits
        metabaw_gpu_limits.install()


def other_sitecustomize():
    """Retain existing interpreter/user startup code without importing ourselves."""
    directory = os.path.normcase(os.path.realpath(os.path.dirname(__file__)))
    paths = [path for path in sys.path
             if os.path.normcase(os.path.realpath(path or os.curdir)) != directory]
    if sys.version_info[0] >= 3:
        from importlib.machinery import PathFinder
        spec = PathFinder.find_spec("sitecustomize", paths)
        if spec is not None and spec.loader is not None and hasattr(spec.loader, "get_code"):
            code = spec.loader.get_code("sitecustomize")
            if code is not None:
                eval(code, {"__name__": "sitecustomize", "__file__": spec.origin,
                            "__spec__": spec, "__builtins__": __builtins__})
    else:
        import imp
        try:
            handle, filename, description = imp.find_module("sitecustomize", paths)
        except ImportError:
            return
        original = sys.modules.pop("sitecustomize", None)
        try:
            imp.load_module("sitecustomize", handle, filename, description)
        finally:
            if original is not None:
                sys.modules["sitecustomize"] = original
            if handle is not None:
                handle.close()


if __name__ == "sitecustomize":
    try:
        install_ipc()
        install_gpu()
        other_sitecustomize()
        # Startup customizations must not accidentally restore a long IPC path.
        install_ipc()
    except BaseException as exc:
        print("[PYTHON RUNTIME ERROR] Cannot initialize task IPC/GPU controls: %s" % exc, file=sys.stderr)
        sys.stderr.flush()
        os._exit(78)
