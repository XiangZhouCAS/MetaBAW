"""Keep Barrnap's Perl/native dependencies separate after a main solve fails."""
from __future__ import annotations

import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tempfile

from .software_versions import PACKAGE_VERSIONS


ENVIRONMENT = "metabaw-barrnap-py311"
LAUNCHER_MARKER = "# MetaBAW isolated barrnap launcher v1"
COMMAND_PACKAGES = {
    "perl": "perl", "barrnap": "barrnap", "cmsearch": "infernal", "cmscan": "infernal",
    "cmfetch": "infernal",
    "bedtools": "bedtools", "aragorn": "aragorn", "any2fasta": "any2fasta",
    "seqkit": "seqkit", "make": "make", "transterm": "transtermhp",
    "ziggypep": "ziggypep", "pyrodigal": "pyrodigal", "diamond": "diamond",
    "taxonkit": "taxonkit",
}


def main_install_constraints() -> tuple[str, ...]:
    """Conda cannot see pip applications' constraints on Barrnap's pyrodigal."""
    from .dependencies import metadata, PYTHON_DISTRIBUTIONS
    try:
        from packaging.requirements import Requirement
    except ImportError:
        from pip._vendor.packaging.requirements import Requirement
    constraints = []
    for application in sorted(set(PYTHON_DISTRIBUTIONS.values())):
        try:
            requirements = metadata.requires(application) or ()
        except metadata.PackageNotFoundError:
            continue
        for value in requirements:
            requirement = Requirement(value)
            if requirement.name.lower() != "pyrodigal" or not requirement.specifier:
                continue
            if requirement.marker and not requirement.marker.evaluate({"extra": ""}):
                continue
            constraints.append("pyrodigal" + str(requirement.specifier))
    return tuple(dict.fromkeys(constraints))


def saved_prefix() -> Path | None:
    from .dependencies import _runtime_config
    try:
        selected = _runtime_config().get("barrnap_runtime", {})
    except (OSError, RuntimeError):
        return None
    value = selected.get("prefix") if isinstance(selected, dict) else None
    if isinstance(value, str) and Path(value).is_absolute():
        return Path(value).resolve()
    return None


def launcher_path(prefix: Path) -> Path:
    # This location preserves normal Conda package-version discovery through
    # the owning bin directory; package records distinguish releases whose
    # upstream scripts advertise the same version banner.
    return prefix / "bin" / "metabaw-barrnap"


def selected_executable() -> str | None:
    prefix = saved_prefix()
    if prefix is None:
        return shutil.which("barrnap")
    launcher = launcher_path(prefix)
    try:
        owned = LAUNCHER_MARKER in launcher.read_text(encoding="utf-8")[:300]
    except (OSError, UnicodeError):
        owned = False
    return str(launcher) if owned else None


def _write_launcher(prefix: Path) -> Path:
    launcher = launcher_path(prefix)
    if launcher.exists() and LAUNCHER_MARKER not in launcher.read_text(encoding="utf-8")[:300]:
        raise RuntimeError(f"An unrelated file occupies the Barrnap launcher path: {launcher}")
    binary = shlex.quote((prefix / "bin").as_posix())
    library = shlex.quote((prefix / "lib").as_posix())
    text = (f"#!/bin/sh\n{LAUNCHER_MARKER}\n"
            "unset PYTHONHOME PYTHONPATH PERL5LIB PERL_LOCAL_LIB_ROOT PERL_MB_OPT PERL_MM_OPT\n"
            f'export PATH={binary}:"$PATH"\n'
            f'export LD_LIBRARY_PATH={library}${{LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}}\n'
            f"exec {shlex.quote((prefix / 'bin/perl').as_posix())} "
            f"{shlex.quote((prefix / 'bin/barrnap').as_posix())} \"$@\"\n")
    launcher.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
            dir=launcher.parent, prefix=".metabaw-barrnap-", delete=False) as handle:
        pending = Path(handle.name)
        handle.write(text)
    try:
        pending.chmod(0o755)
        pending.replace(launcher)
    finally:
        pending.unlink(missing_ok=True)
    return launcher


def scan_issue(executable: str, *, database: Path | None = None) -> str | None:
    """Exercise both bundled rRNA models, without downloads or user inputs."""
    try:
        from .rna_databases import barrnap_arguments, native_environment
        with tempfile.TemporaryDirectory(prefix="metabaw-barrnap-probe-") as temporary:
            fasta = Path(temporary) / "probe.fa"
            fasta.write_text(">metabaw_dependency_probe\n" + "ACGT" * 50 + "\n", encoding="ascii")
            for kingdom in ("bac", "arc"):
                process = subprocess.run([executable, *barrnap_arguments(database),
                    "--kingdom", kingdom, "--threads", "1", str(fasta)],
                    env=native_environment(executable), capture_output=True, text=True, check=False, timeout=30)
                if process.returncode or not process.stdout.lstrip().startswith("##gff-version 3"):
                    detail = " | ".join((process.stderr or process.stdout or "no GFF output").strip().splitlines()[-5:])
                    return f"Barrnap {kingdom} rRNA runtime check failed (exit {process.returncode}): {detail}"
    except (OSError, subprocess.SubprocessError) as exc:
        return f"Barrnap rRNA runtime check could not start: {exc}"
    return None


def _package_files(prefix: Path) -> tuple[str, ...] | None:
    """Read the installed package inventory; never infer it from a recipe."""
    for record in sorted((prefix / "conda-meta").glob("barrnap-*.json")):
        try:
            data = json.loads(record.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if not isinstance(data, dict):
            continue
        if data.get("name") != "barrnap" or data.get("version") != PACKAGE_VERSIONS["barrnap"]:
            continue
        files = data.get("files")
        if not isinstance(files, list):
            paths_data = data.get("paths_data")
            paths = paths_data.get("paths", []) if isinstance(paths_data, dict) else []
            if not isinstance(paths, list):
                paths = []
            files = [item.get("_path") for item in paths if isinstance(item, dict)]
        if files and all(isinstance(value, str) for value in files):
            return tuple(value.replace("\\", "/") for value in files)
    return None


def database_directory(prefix: Path) -> Path:
    """Match Barrnap's FindBin::RealBin/../db, including Bioconda symlinks."""
    entry = prefix / "bin" / "barrnap"
    if entry.is_file():
        return entry.resolve().parent.parent / "db"
    # Inspect the exact package record when a platform cannot reproduce the
    # entry-point symlink. Do not search arbitrary old versions under share/.
    for relative in _package_files(prefix) or ():
        if not relative.endswith("/bin/barrnap"):
            continue
        script = prefix / relative
        if script.resolve().is_relative_to(prefix.resolve()) and script.is_file():
            return script.resolve().parent.parent / "db"
    return prefix / "db"


def _model_problem(prefix: Path) -> tuple[str | None, tuple[str, ...]]:
    from .rna_databases import selected_database
    directory = selected_database("barrnap") or database_directory(prefix)
    models = tuple(directory / kingdom / f"{kingdom}.rRNA.cm" for kingdom in ("bac", "arc"))
    missing = tuple(path for path in models if not path.is_file() or path.stat().st_size == 0)
    if not missing:
        return None, ()
    files = _package_files(prefix)
    # Reinstall can restore only files that actually belong to the package.
    # Bioconda 1.10.5 build 0 bundles DIAMOND databases but no rRNA CMs.
    if files is not None and all(path.resolve().is_relative_to(prefix.resolve())
            and path.resolve().relative_to(prefix.resolve()).as_posix() in files for path in missing):
        return "bundled Barrnap rRNA model is missing: " + ", ".join(map(str, missing)), ("barrnap",)
    build = directory.parent / "build"
    detail = ("The installed Barrnap package does not bundle these rRNA models. " if files is not None else
              "The package inventory does not identify these models as bundled files. ")
    return ("Barrnap rRNA reference models need setup: " + ", ".join(map(str, missing)) + ". "
            + detail + f"Build bac.rRNA.cm and arc.rRNA.cm using {build / 'Makefile'}, "
            + f"then copy them to {directory / 'bac'} and {directory / 'arc'}, respectively. "
            + "Run `metabaw check --all` to download and configure these models automatically, "
            + "or use `metabaw check --barrnap-db /path/to/db` for existing models. "
            + "reinstalling the same package cannot supply models absent from its inventory.", ())


def reference_model_issue(executable: str) -> str | None:
    """Identify unbundled reference data separately from software failures."""
    from .dependencies import _conda_package_version
    from .rna_databases import selected_database
    prefix = Path(executable).expanduser().parent.parent.resolve()
    if selected_database("barrnap") is None and (not (prefix / "conda-meta").is_dir()
            or _conda_package_version(executable, "barrnap") != PACKAGE_VERSIONS["barrnap"]):
        # System/source installs retain their real native scan check; do not
        # guess database locations from another Conda environment's inventory.
        return None
    problem, repair = _model_problem(prefix)
    return problem if problem and not repair else None


def _runtime_problem(prefix: Path) -> tuple[str | None, tuple[str, ...]]:
    from .dependencies import _conda_package_version
    version = _conda_package_version(prefix / "bin/barrnap", "barrnap")
    if version != PACKAGE_VERSIONS["barrnap"]:
        return f"Barrnap package version is {version or 'unknown'}", ("barrnap",)
    missing = [command for command in COMMAND_PACKAGES
               if not shutil.which(command, path=str(prefix / "bin"))]
    if missing:
        return "missing runtime commands: " + ", ".join(missing), tuple(dict.fromkeys(
            COMMAND_PACKAGES[command] for command in missing))
    problem, packages = _model_problem(prefix)
    if problem:
        return problem, packages
    executable = _write_launcher(prefix)
    process = subprocess.run([str(executable), "--version"], capture_output=True, text=True,
                             check=False, timeout=30)
    if process.returncode:
        detail = process.stderr or process.stdout or f"exit {process.returncode}"
        modules = {"Path/Tiny.pm": "perl-path-tiny", "File/Which.pm": "perl-file-which",
                   "List/MoreUtils.pm": "perl-list-moreutils"}
        return detail, tuple(package for module, package in modules.items() if module in detail)
    return scan_issue(str(executable)), ()


def install_fallback(frontend: str, *, prepare_database: bool = False) -> Path:
    """Reuse a working fallback; create only in a verified unused directory."""
    from . import dependencies as deps
    prefix = saved_prefix() or Path(sys.prefix).resolve().parent / ENVIRONMENT
    if prefix == Path(sys.prefix).resolve():
        raise RuntimeError("Barrnap's fallback must differ from the MetaBAW main environment")
    for number in range(1, 101):
        candidate = prefix if number == 1 else prefix.with_name(prefix.name + f"-{number}")
        if candidate.resolve() == Path(sys.prefix).resolve():
            continue
        occupied = candidate.exists() or candidate.is_symlink()
        if occupied and not (candidate / "conda-meta").is_dir():
            continue
        if occupied:
            python = deps._conda_package_version(candidate / "bin/python", "python")
            if python and not re.match(r"3\.(11|12|13)(?:\.|$)", python):
                continue
        prefix = candidate
        break
    else:
        raise RuntimeError("No unused Barrnap fallback environment directory was found")
    exists = (prefix / "conda-meta").is_dir()
    problem, packages = _runtime_problem(prefix) if exists else ("environment not installed", ("barrnap",))
    if prepare_database and exists and problem and not packages and "reference models need setup:" in problem:
        from .rna_databases import ensure_barrnap
        ensure_barrnap(str(prefix / "bin/barrnap"))
        problem, packages = _runtime_problem(prefix)
    if problem:
        if exists and not packages:
            if "reference models need setup:" in problem:
                raise RuntimeError(problem)
            raise RuntimeError(f"The existing Barrnap environment needs a targeted repair: {problem}; it was preserved")
        selected = tuple(deps.pinned_package(package) for package in packages)
        restore = tuple(spec for package in selected
                        if exists and (spec := deps._conda_command_restore_spec(prefix, package)))
        remaining = tuple(package for package in selected
                          if not exists or deps._conda_command_restore_spec(prefix, package) is None)
        print(f"[BARRNAP FALLBACK] Configuring Barrnap {PACKAGE_VERSIONS['barrnap']} in {prefix}", flush=True)
        for packages, restoring in ((remaining, False), (restore, True)):
            if not packages:
                continue
            command = [frontend, "install" if exists else "create", "--yes", "--prefix", str(prefix),
                       "--override-channels", "--channel", "conda-forge", "--channel", "bioconda",
                       *(("--force-reinstall", "--no-deps") if restoring else
                         ("--freeze-installed",) if exists else ("--no-default-packages",)),
                       *(("python=3.11",) if not exists else ()), *packages]
            process = deps.run_conda_transaction(command)
            if process.returncode:
                raise RuntimeError(f"Barrnap fallback installation failed (exit {process.returncode})")
        if prepare_database:
            from .rna_databases import ensure_barrnap
            ensure_barrnap(str(prefix / "bin/barrnap"))
        problem, _ = _runtime_problem(prefix)
        if problem:
            raise RuntimeError(f"Barrnap fallback runtime validation failed: {problem}")
    config = deps._runtime_config()
    config["barrnap_runtime"] = {"prefix": str(prefix)}
    path = deps.isolated_environment_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
            prefix=".barrnap-config-", delete=False) as handle:
        pending = Path(handle.name)
        json.dump(config, handle, indent=2, sort_keys=True)
        handle.write("\n")
    try:
        pending.replace(path)
    finally:
        pending.unlink(missing_ok=True)
    return prefix
