"""Prepare and reuse pinned RNA-tool models without changing tool environments."""
from __future__ import annotations

import gzip
import hashlib
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .run_lock import RunLock


RFAM_URL = "https://ftp.ebi.ac.uk/pub/databases/Rfam/CURRENT/Rfam.cm.gz"
# These accession lists are the pinned Barrnap v1.10.5 build/*.rRNA.tsv files.
BARRNAP_MODELS = {"bac": ("RF00001", "RF00177", "RF02541"),
                  "arc": ("RF00001", "RF00002", "RF01959", "RF02540")}
TRNASCAN_URL = "https://codeload.github.com/UCSC-LoweLab/tRNAscan-SE/tar.gz/refs/tags/v2.0.9"
TRNASCAN_SHA256 = "02d19614c99a6f115a007de66143cd92236a4bc67ef822668b604351fd28cca4"
TRNASCAN_FILES = tuple(
    name for domain in ("bact", "arch") for name in (
        f"TRNAinf-{domain}.cm", f"TRNAinf-{domain}-ns.cm", f"TRNAinf-{domain}-SeC.cm",
        f"TRNA2-{domain}.cm", f"TRNAinf-{domain}-iso",
        *(f"TRNAinf-{domain}-iso.i1{suffix}" for suffix in "fimp"))) + (
    "Cren-eury-BHB-noncan.cm", "Thaum-BHB-noncan.cm", "TRNAinf-arch-5h.cm", "TRNAinf-arch-3h.cm")
ENVIRONMENT_NAMES = {"barrnap": "BARRNAP_DB", "trnascan": "TRNASCAN_SE_DB"}


def cache_directory(kind: str) -> Path:
    name, version = ("barrnap", "1.10.5") if kind == "barrnap" else ("trnascan-se", "2.0.9")
    return Path.home() / ".cache" / "metabaw" / name / version


def selected_database(kind: str) -> Path | None:
    from .dependencies import _database_config
    value = os.environ.get(ENVIRONMENT_NAMES[kind]) or _database_config().get(kind)
    if value:
        return Path(value).expanduser().resolve()
    cache = cache_directory(kind)
    return cache if not missing_models(kind, cache) else None


def missing_models(kind: str, directory: Path) -> tuple[str, ...]:
    if kind == "trnascan" and directory.name == "models":
        directory = directory.parent
    names = (tuple(f"{kingdom}/{kingdom}.rRNA.cm" for kingdom in BARRNAP_MODELS)
             if kind == "barrnap" else tuple("models/" + name for name in TRNASCAN_FILES))
    return tuple(name for name in names
                 if not (directory / name).is_file() or (directory / name).stat().st_size == 0)


def _atomic_write(destination: Path, content: bytes) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=destination.parent, prefix=".metabaw-rna-", delete=False) as stream:
        pending = Path(stream.name)
        stream.write(content)
    try:
        pending.replace(destination)
    finally:
        pending.unlink(missing_ok=True)


def _download(url: str, destination: Path, *, sha256: str | None = None) -> None:
    for attempt in range(3):
        try:
            digest = hashlib.sha256()
            request = Request(url, headers={"User-Agent": "MetaBAW/0.1.0"})
            with urlopen(request, timeout=60) as source, destination.open("wb") as target:
                total = 0
                while block := source.read(1024 * 1024):
                    target.write(block)
                    digest.update(block)
                    total += len(block)
                expected = source.headers.get("Content-Length")
                if not total or (expected is not None and total != int(expected)):
                    raise OSError("Incomplete RNA reference download")
            if sha256 and digest.hexdigest() != sha256:
                raise ValueError("RNA reference archive does not match its pinned SHA256")
            return
        except (OSError, URLError) as exc:
            destination.unlink(missing_ok=True)
            if attempt == 2 or (isinstance(exc, HTTPError) and exc.code not in {408, 429, 500, 502, 503, 504}):
                raise RuntimeError(f"RNA database download failed: {url}: {exc}") from exc
            time.sleep(attempt + 1)


def native_environment(executable: str) -> dict[str, str]:
    environment = os.environ.copy()
    prefix = Path(executable).expanduser().parent.parent.resolve()
    if (prefix / "conda-meta").is_dir():
        environment["PATH"] = str(prefix / "bin") + os.pathsep + environment.get("PATH", "")
        environment["LD_LIBRARY_PATH"] = str(prefix / "lib") + (
            os.pathsep + environment["LD_LIBRARY_PATH"] if environment.get("LD_LIBRARY_PATH") else "")
    return environment


def barrnap_arguments(directory: Path | None = None) -> list[str]:
    selected = directory if directory is not None else selected_database("barrnap")
    return ["--dbdir", str(selected)] if selected is not None else []


def _check_barrnap(executable: str, directory: Path) -> None:
    from .barrnap_runtime import scan_issue
    missing = missing_models("barrnap", directory)
    if missing:
        raise RuntimeError(f"Barrnap database {directory} is incomplete: " + ", ".join(missing))
    problem = scan_issue(executable, database=directory)
    if problem:
        raise RuntimeError(problem)


def ensure_barrnap(executable: str, explicit: str | None = None) -> Path:
    from .barrnap_runtime import database_directory
    from .dependencies import save_database_path
    selected = Path(explicit).expanduser().resolve() if explicit else selected_database("barrnap")
    if not explicit and not os.environ.get("BARRNAP_DB") and selected == cache_directory("barrnap") and missing_models("barrnap", selected):
        selected = None
    if selected is not None:
        _check_barrnap(executable, selected)
        save_database_path("barrnap", selected)
        return selected
    installed = database_directory(Path(executable).expanduser().parent.parent.resolve())
    if not missing_models("barrnap", installed):
        _check_barrnap(executable, installed)
        return installed
    destination = cache_directory("barrnap")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with RunLock(destination.parent / ".database.lock"):
        if missing_models("barrnap", destination):
            environment = native_environment(executable)
            cmfetch = shutil.which("cmfetch", path=environment.get("PATH"))
            if not cmfetch:
                raise RuntimeError("Barrnap model preparation requires Infernal's cmfetch executable")
            with tempfile.TemporaryDirectory(prefix=".prepare-", dir=destination.parent) as temporary:
                stage = Path(temporary)
                compressed, rfam = stage / "Rfam.cm.gz", stage / "Rfam"
                _download(RFAM_URL, compressed)
                with gzip.open(compressed, "rb") as source, rfam.open("wb") as target:
                    shutil.copyfileobj(source, target, 1024 * 1024)
                for kingdom, accessions in BARRNAP_MODELS.items():
                    model = stage / kingdom / f"{kingdom}.rRNA.cm"
                    model.parent.mkdir()
                    keys = stage / f"{kingdom}.ids"
                    keys.write_text("\n".join(accessions) + "\n", encoding="ascii")
                    with model.open("wb") as target:
                        result = subprocess.run([cmfetch, "-f", str(rfam), str(keys)], stdout=target,
                            stderr=subprocess.PIPE, env=environment, check=False, timeout=300)
                    if result.returncode:
                        detail = (result.stderr or b"").decode(errors="replace")
                        raise RuntimeError(f"Barrnap model extraction failed: {detail[-1500:]}")
                _check_barrnap(executable, stage)
                for kingdom in BARRNAP_MODELS:
                    relative = Path(kingdom) / f"{kingdom}.rRNA.cm"
                    _atomic_write(destination / relative, (stage / relative).read_bytes())
        _check_barrnap(executable, destination)
        save_database_path("barrnap", destination)
    return destination


def default_trnascan_config(executable: str) -> Path | None:
    script = Path(executable).expanduser()
    candidates = [script.parent / "tRNAscan-SE.conf", script.resolve().parent / "tRNAscan-SE.conf"]
    try:
        text = script.read_text(encoding="utf-8", errors="replace")[:16384]
        match = re.search(r'\$default_conf\s*=\s*[\"\x27]([^\"\x27]+)', text)
        if match and "@" not in match[1]:
            candidates.insert(0, Path(match[1]).expanduser())
    except OSError:
        pass
    return next((path.resolve() for path in candidates if path.is_file()), None)


def _configuration(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        key, separator, value = line.partition(":")
        if separator:
            values[key.strip()] = re.sub(r"\{([^{}]+)\}", lambda m: values.get(m[1], m[0]), value.strip())
    return values


def trnascan_config(executable: str, directory: Path | None = None) -> Path | None:
    selected = directory if directory is not None else selected_database("trnascan")
    if selected is None:
        return default_trnascan_config(executable)
    if selected.is_file():
        return selected
    if selected.name == "models":
        selected = selected.parent
    template = next((p for p in (selected / "tRNAscan-SE.conf.src", selected / "tRNAscan-SE.conf",
                                default_trnascan_config(executable)) if p is not None and p.is_file()), None)
    if template is None:
        raise RuntimeError("tRNAscan-SE configuration template is missing; supply a complete 2.0.9 data directory or config file")
    binary = Path(executable).expanduser().parent.resolve()
    environment = native_environment(executable)
    cmsearch = shutil.which("cmsearch", path=environment.get("PATH"))
    infernal = Path(cmsearch).parent.resolve() if cmsearch else binary
    text = template.read_text(encoding="utf-8")
    text = re.sub(r"(?m)^bin_dir:\s*.*$", "bin_dir: " + binary.as_posix(), text)
    text = re.sub(r"(?m)^lib_dir:\s*.*$", "lib_dir: " + selected.as_posix(), text)
    text = re.sub(r"(?m)^infernal_dir:\s*.*$", "infernal_dir: " + infernal.as_posix(), text)
    text = re.sub(r"(?m)^(cm_dir|cove_cm_dir|isotype_cm_dir|mito_cm_db_dir|mito_cm_mammal_dir|mito_cm_vert_dir):\s*.*$",
                  lambda m: m[1] + ": " + (selected / "models").as_posix(), text)
    key = hashlib.sha256((str(binary) + "\n" + str(selected)).encode()).hexdigest()[:20]
    output = cache_directory("trnascan") / "configurations" / (key + ".conf")
    content = text.encode("utf-8")
    if not output.is_file() or output.read_bytes() != content:
        _atomic_write(output, content)
    return output


def trnascan_arguments(executable: str) -> list[str]:
    if selected_database("trnascan") is None:
        return []
    config = trnascan_config(executable)
    return ["-c", str(config)] if config is not None else []


def trnascan_problem(executable: str, *, config: Path | None = None, scan: bool = True) -> str | None:
    from .dependencies import _conda_package_version
    selected = selected_database("trnascan")
    try:
        config = config if config is not None else trnascan_config(executable)
    except (OSError, ValueError, RuntimeError) as exc:
        return str(exc)
    if config is None:
        if selected is not None or _conda_package_version(executable, "trnascan-se") == "2.0.9":
            return "tRNAscan-SE model configuration is missing; run metabaw check --all or use --trnascan-db"
        return None
    try:
        values = _configuration(config)
    except (OSError, ValueError) as exc:
        return f"tRNAscan-SE configuration {config} could not be read: {exc}"
    # Read the real config rather than guessing a Conda share-directory name.
    root = Path(values.get("cm_dir", ""))
    selected_paths = {}
    for domain, label in (("bact", "bacteria"), ("arch", "archaea")):
        for name, key in ((f"TRNAinf-{domain}.cm", f"cm.{label}"),
                          (f"TRNAinf-{domain}-ns.cm", f"cm.{label}-ns"),
                          (f"TRNAinf-{domain}-SeC.cm", f"{domain}_cm.SeC"),
                          (f"TRNA2-{domain}.cm", f"cove_cm.{label}"),
                          (f"TRNAinf-{domain}-iso", f"isotype_cm.{label}")):
            selected_paths[name] = Path(values.get(key, str(root / name)))
        for suffix in "fimp":
            name = f"TRNAinf-{domain}-iso.i1{suffix}"
            selected_paths[name] = Path(str(selected_paths[f"TRNAinf-{domain}-iso"]) + f".i1{suffix}")
    for name, key in (("Cren-eury-BHB-noncan.cm", "nci_cm.cren"), ("Thaum-BHB-noncan.cm", "nci_cm.thaum"),
                      ("TRNAinf-arch-5h.cm", "cm.arch_5h"), ("TRNAinf-arch-3h.cm", "cm.arch_3h")):
        selected_paths[name] = Path(values.get(key, str(root / name)))
    missing = tuple(str(path) for path in selected_paths.values() if not path.is_file() or path.stat().st_size == 0)
    if missing:
        return f"tRNAscan-SE database {root} is incomplete: " + ", ".join(missing)
    if not scan:
        return None
    with tempfile.TemporaryDirectory(prefix="metabaw-trna-probe-") as temporary:
        directory = Path(temporary)
        fasta = directory / "probe.fa"
        fasta.write_text(">metabaw_dependency_probe\n" + "ACGT" * 50 + "\n", encoding="ascii")
        for mode in ("-B", "-A"):
            table = directory / (mode[1:] + ".tsv")
            try:
                result = subprocess.run([executable, "-c", str(config), mode, "--thread", "1", "-o", str(table), str(fasta)],
                    cwd=directory, env=native_environment(executable), capture_output=True, text=True, check=False, timeout=120)
            except subprocess.TimeoutExpired as exc:
                return f"tRNAscan-SE model-loading check timed out after {exc.timeout} seconds; readiness is unconfirmed"
            except OSError as exc:
                return f"tRNAscan-SE model-loading check could not start: {exc}"
            diagnostic = "\n".join(part for part in (result.stdout, result.stderr) if part)
            completed = table.is_file() or bool(re.search(r"\b\d+\s+seqs scanned\b", diagnostic))
            if result.returncode or not completed or re.search(r"(?i)\b(?:fatal|error):", diagnostic):
                detail = (result.stderr or result.stdout or "no output table")[-1500:]
                return f"tRNAscan-SE {mode} model loading failed: {detail}"
    return None


def _extract_trnascan(archive: Path, destination: Path) -> None:
    with tarfile.open(archive, "r:gz") as source:
        for member in source:
            parts = PurePosixPath(member.name).parts
            if not member.isfile() or not parts or parts[0] != "tRNAscan-SE-2.0.9":
                continue
            relative = None
            if len(parts) >= 4 and parts[1] == "lib" and parts[2] in {"models", "gcode"}:
                relative = PurePosixPath(*parts[2:])
            elif parts[1:] == ("tRNAscan-SE.conf.src",):
                relative = PurePosixPath("tRNAscan-SE.conf.src")
            if relative is None or ".." in relative.parts:
                continue
            target = destination.joinpath(*relative.parts)
            if not target.resolve().is_relative_to(destination.resolve()):
                raise ValueError("Unsafe RNA reference archive member")
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.extractfile(member) as data, target.open("wb") as stream:
                shutil.copyfileobj(data, stream)


def ensure_trnascan(executable: str, explicit: str | None = None) -> Path | None:
    from .dependencies import save_database_path
    selected = Path(explicit).expanduser().resolve() if explicit else selected_database("trnascan")
    if not explicit and not os.environ.get("TRNASCAN_SE_DB") and selected == cache_directory("trnascan") and missing_models("trnascan", selected):
        selected = None
    if selected is not None:
        config = trnascan_config(executable, selected)
        problem = trnascan_problem(executable, config=config)
        if problem:
            raise RuntimeError(problem)
        save_database_path("trnascan", selected)
        return selected
    default = default_trnascan_config(executable)
    if default is not None and not trnascan_problem(executable, config=default, scan=False):
        problem = trnascan_problem(executable, config=default)
        if problem:
            raise RuntimeError(problem)
        return Path(_configuration(default)["cm_dir"])
    destination = cache_directory("trnascan")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with RunLock(destination.parent / ".database.lock"):
        if missing_models("trnascan", destination):
            with tempfile.TemporaryDirectory(prefix=".prepare-", dir=destination.parent) as temporary:
                stage = Path(temporary)
                archive = stage / "source.tar.gz"
                _download(TRNASCAN_URL, archive, sha256=TRNASCAN_SHA256)
                data = stage / "data"
                _extract_trnascan(archive, data)
                config = trnascan_config(executable, data)
                problem = trnascan_problem(executable, config=config)
                if problem:
                    raise RuntimeError(problem)
                for source in data.rglob("*"):
                    if source.is_file():
                        _atomic_write(destination / source.relative_to(data), source.read_bytes())
        config = trnascan_config(executable, destination)
        problem = trnascan_problem(executable, config=config)
        if problem:
            raise RuntimeError(problem)
        save_database_path("trnascan", destination)
    return destination
