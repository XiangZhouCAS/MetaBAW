"""Try COMEBin in the main environment, then retain a verified isolated runtime."""
from __future__ import annotations

from dataclasses import dataclass, replace
from importlib import metadata
import json
from pathlib import Path
import re
import subprocess
import sys

from . import dependencies as deps
from .comebin_runtime import COMEBIN_ENVIRONMENT, COMEBIN_RUNTIME_PACKAGES


@dataclass(frozen=True)
class ComebinRuntime:
    status: deps.IsolatedEnvironmentStatus
    environment: str | None = None

    @property
    def available(self) -> bool:
        return self.status.available


def saved_comebin_environment() -> str | None:
    selected = deps._runtime_config().get("comebin_runtime", {})
    if isinstance(selected, dict) and selected.get("mode") == "isolated":
        environment = selected.get("environment")
        if isinstance(environment, str) and environment.strip():
            return environment
    return None


def _save_runtime(runtime: ComebinRuntime) -> ComebinRuntime:
    if not runtime.available:
        raise RuntimeError("COMEBin failed its runtime checks; its selection was not saved")
    config = deps._runtime_config()
    config["comebin_runtime"] = (
        {"mode": "isolated", "environment": runtime.environment}
        if runtime.environment else {"mode": "main"}
    )
    path = deps.isolated_environment_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(config, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)
    return runtime


def comebin_runtime_status() -> ComebinRuntime:
    environment = saved_comebin_environment()
    if environment:
        return ComebinRuntime(
            deps.isolated_environment_status(deps.ISOLATED_TOOLS["comebin"], environment),
            environment,
        )
    status = deps.main_comebin_status()
    if status.available:
        try:
            _, conflicts = _main_constraints()
            if conflicts:
                status = replace(status, error="; ".join(conflicts))
        except (ImportError, ValueError) as exc:
            status = replace(status, error=f"main-environment dependency check failed: {exc}")
    return ComebinRuntime(status)


def _main_constraints() -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Conda cannot otherwise see exact requirements declared by pip applications."""
    try:
        from packaging.requirements import Requirement
        from packaging.specifiers import SpecifierSet
    except ImportError:
        from pip._vendor.packaging.requirements import Requirement
        from pip._vendor.packaging.specifiers import SpecifierSet
    aliases = {"torch": "pytorch", "igraph": "python-igraph"}
    bounds = {}
    for value in COMEBIN_RUNTIME_PACKAGES:
        # Package specifications here have no channel/build selectors.
        name = re.split(r"[<>=!~]", value, maxsplit=1)[0]
        constraint = value[len(name):]
        if constraint.startswith("=") and not constraint.startswith("=="):
            constraint = "=" + constraint
        bounds[name] = SpecifierSet(constraint)
    constraints, conflicts = [], []
    for distribution in sorted(set(deps.PYTHON_DISTRIBUTIONS.values())):
        try:
            requirements = metadata.requires(distribution) or ()
        except metadata.PackageNotFoundError:
            continue
        for raw in requirements:
            requirement = Requirement(raw)
            if requirement.marker and not requirement.marker.evaluate({"extra": ""}):
                continue
            name = aliases.get(requirement.name.lower().replace("_", "-"),
                               requirement.name.lower().replace("_", "-"))
            if name not in bounds or not requirement.specifier:
                continue
            constraints.append(name + str(requirement.specifier))
            for specifier in requirement.specifier:
                if specifier.operator == "==" and "*" not in specifier.version:
                    if specifier.version not in bounds[name]:
                        conflicts.append(f"{distribution} requires {requirement}; "
                                         f"COMEBin requires {name}{bounds[name]}")
    return tuple(dict.fromkeys(constraints)), tuple(dict.fromkeys(conflicts))


def _main_install_packages(status: deps.IsolatedEnvironmentStatus) -> tuple[str, ...]:
    if status.executable is None:
        return COMEBIN_RUNTIME_PACKAGES
    python_packages, conda_packages, _ = deps._isolated_repair_targets(status)
    if conda_packages == COMEBIN_RUNTIME_PACKAGES:
        return COMEBIN_RUNTIME_PACKAGES
    aliases = {"pyyaml": "pyyaml", "checkm-genome": "checkm-genome",
               "torch": "pytorch", "igraph": "python-igraph"}
    requested = {aliases.get(name.lower(), name.lower()) for name in python_packages}
    packages = tuple(package for package in COMEBIN_RUNTIME_PACKAGES
                     if re.split(r"[<>=!~\s]", package, maxsplit=1)[0] in requested)
    targeted = tuple(dict.fromkeys((*conda_packages, *packages)))
    if not targeted:
        raise RuntimeError("Cannot identify a targeted repair for the existing main-environment COMEBin: "
                           + (status.error or "unknown runtime failure"))
    return targeted


def _fallback_prefix(environment: str | None) -> Path:
    requested = environment or COMEBIN_ENVIRONMENT
    if Path(requested).name == "metabaw-comebin-py37":
        requested = COMEBIN_ENVIRONMENT
    selector, value = deps.conda_environment_selector(requested)
    prefix = Path(value) if selector == "--prefix" else Path(sys.prefix).parent / value
    prefix = prefix.resolve()
    if prefix == Path(sys.prefix).resolve():
        raise RuntimeError("COMEBin's fallback environment must differ from the MetaBAW main environment")
    return prefix


def _install_fallback(environment: str | None) -> ComebinRuntime:
    prefix = _fallback_prefix(environment)
    spec = deps.ISOLATED_TOOLS["comebin"]
    for number in range(1, 101):
        target = prefix if number == 1 else prefix.with_name(prefix.name + f"-{number}")
        status = deps.isolated_environment_status(spec, str(target))
        if status.available:
            return _save_runtime(ComebinRuntime(status, str(target)))
        compatible = spec.supports_python(status.python_version)
        occupied = target.exists() or target.is_symlink()
        if status.error and status.error.startswith("environment dependency probe failed:"):
            raise RuntimeError(status.error)
        if occupied and not compatible:
            # An unusable directory can contain user files or an older Python.
            continue
        status = deps.install_isolated_environment(spec, str(target), status.frontend)
        return _save_runtime(ComebinRuntime(status, status.environment))
    raise RuntimeError("No unused COMEBin fallback environment was found; select a new --comebin-env prefix")


def install_comebin_runtime(environment: str | None = None) -> ComebinRuntime:
    saved = saved_comebin_environment()
    if saved:
        # A successful fallback is a reusable installation, not a reason to
        # repeat a previously failed main-environment solve on every check.
        return _install_fallback(saved)
    print("[COMEBIN MAIN] Checking installation in the MetaBAW main environment.", flush=True)
    try:
        constraints, conflicts = _main_constraints()
        if conflicts:
            raise RuntimeError("; ".join(conflicts))
        status = deps.main_comebin_status()
        if status.available:
            return _save_runtime(ComebinRuntime(status))
        frontend = deps.conda_frontend()
        if frontend is None:
            raise RuntimeError("mamba, micromamba, or conda is unavailable")
        python = f"{sys.version_info.major}.{sys.version_info.minor}"
        if not deps.ISOLATED_TOOLS["comebin"].supports_python(python):
            raise RuntimeError(f"the main Python {python} is incompatible with COMEBin 1.1.0")
        packages = _main_install_packages(status)
        command = [frontend, "install", "--yes", "--prefix", str(Path(sys.prefix).resolve()),
                   "--override-channels", "--channel", "conda-forge", "--channel", "bioconda",
                   f"python={python}",
                   *(("--freeze-installed",) if packages != COMEBIN_RUNTIME_PACKAGES else ()),
                   *packages, *constraints]
        dry_run = deps.run_conda_transaction([*command, "--dry-run"])
        if dry_run.returncode:
            raise RuntimeError(f"main-environment dependency solve failed (exit {dry_run.returncode})")
        process = deps.run_conda_transaction(command)
        if process.returncode:
            raise RuntimeError(f"main-environment installation failed (exit {process.returncode})")
        status = deps.main_comebin_status()
        if not status.available:
            raise RuntimeError(status.error or "main-environment runtime validation failed")
        return _save_runtime(ComebinRuntime(status))
    except (OSError, ImportError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        print(f"[COMEBIN FALLBACK] {exc}; using a separate Python 3.11 environment.",
              file=sys.stderr, flush=True)
    return _install_fallback(environment)
